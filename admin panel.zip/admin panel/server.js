const express = require('express');
const mysql = require('mysql2');

const app = express();
const port = 3000;
const cors = require('cors'); // Add this near your other requires
app.use(cors());              // Add this before your app.post route

// Middleware to parse JSON bodies
app.use(express.json());

// Serve static files from the 'public' directory
app.use(express.static('public'));

// Create a connection to the database
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'kartik', // Replace with your actual password
    database: 'inquiry_db'
});

// Connect to MySQL
db.connect((err) => {
    if (err) {
        console.error('Error connecting to MySQL:', err);
        return;
    }
    console.log('Connected to MySQL database.');
});

// POST endpoint to store data
app.post('/api/inquiries', (req, res) => {
    const { name, email, message } = req.body;

    const sql = 'INSERT INTO inquiries (name, email, message) VALUES (?, ?, ?)';
    
    db.query(sql, [name, email, message], (err, result) => {
        if (err) {
            console.error('Error inserting data:', err);
            return res.status(500).json({ error: 'Database error' });
        }
        res.status(201).json({ 
            message: 'Inquiry stored successfully!', 
            id: result.insertId 
        });
    });
});

// GET endpoint for the root URL
app.get('/', (req, res) => {
    res.send('Backend server is running!');
});

// Start the server
app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});